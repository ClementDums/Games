
public class Bonus {

}
